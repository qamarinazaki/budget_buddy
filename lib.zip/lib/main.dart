import 'package:flutter/material.dart';

import 'dashboard.dart';
import 'saving_goals.dart';
import 'bill_reminder.dart';
import 'income_tracker.dart';
import 'analytics_report.dart';
import 'community_tips_forum.dart';
import 'budget_plan.dart';
import 'campus_deals.dart';

void main() {
  runApp(const BudgetBuddyApp());
}

class BudgetBuddyApp extends StatelessWidget {
  const BudgetBuddyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Budget Buddy',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const MainDashboard(),
    );
  }
}

class MainDashboard extends StatelessWidget {
  const MainDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Budget Buddy'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [

            _buildNavButton(
              context,
              icon: Icons.dashboard,
              label: 'Dashboard',
              page: const BudgetBuddyDashboard(),
            ),
            const SizedBox(height: 12),

            _buildNavButton(
              context,
              icon: Icons.account_balance_wallet,
              label: 'Budget Plan',
              page: const BudgetPage(),
            ),

            const SizedBox(height: 12),

            _buildNavButton(
              context,
              icon: Icons.local_offer,
              label: 'Campus Deals',
              page: const CampusDealsPage(),
            ),
            const SizedBox(height: 12),

            _buildNavButton(
              context,
              icon: Icons.savings,
              label: 'Saving Goals',
              page: const SavingGoalsPage(),
            ),

            const SizedBox(height: 12),

            _buildNavButton(
              context,
              icon: Icons.notifications_active,
              label: 'Bill Reminder',
              page: const BillReminderPage(),
            ),

            const SizedBox(height: 12),

            _buildNavButton(
              context,
              icon: Icons.add_chart,
              label: 'Income Tracker',
              page: const IncomeTracker(),
            ),

            const SizedBox(height: 12),

            _buildNavButton(
              context,
              icon: Icons.analytics,
              label: 'Analytics Report',
              page: const AnalyticsReport(),
            ),

            const SizedBox(height: 12),

            _buildNavButton(
              context,
              icon: Icons.forum,
              label: 'Community Tips Forum',
              page: const CommunityTipsForum(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNavButton(
      BuildContext context, {
        required IconData icon,
        required String label,
        required Widget page,
      }) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        icon: Icon(icon),
        label: Text(label),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => page,
            ),
          );
        },
      ),
    );
  }
}