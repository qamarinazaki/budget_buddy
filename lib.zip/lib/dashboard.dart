import 'package:flutter/material.dart';
import 'analytics_report.dart';
import 'community_tips_forum.dart';
import 'income_tracker.dart';

class BudgetBuddyDashboard extends StatelessWidget {
  const BudgetBuddyDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFEF2F2),
      // Adding the Drawer (Side Menu)
      drawer: _buildDrawer(context),
      body: Stack(
        children: [
          // 1. Futuristic Ambient Glow
          Positioned(
            top: 150,
            right: -200,
            child: Container(
              width: 500,
              height: 500,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    Colors.purpleAccent.withValues(alpha: 0.12),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),

          // 2. Main Layout
          SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 12),
                // Custom Top Bar with Menu & Back buttons
                _buildTopBar(context),

                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    children: [
                      const SizedBox(height: 20),
                      _buildTopSection(),
                      const SizedBox(height: 24),
                      _buildBalanceCard(),
                      const SizedBox(height: 24),
                      _buildProgressCards(),
                      const SizedBox(height: 24),
                      _buildAnalyticsSection(),
                      const SizedBox(height: 24),
                      _buildQuickActions(),
                      const SizedBox(height: 24),
                      _buildRecentTransactions(),
                      const SizedBox(height: 100),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Floating Circular "+" Button
          Positioned(
            bottom: 25,
            right: 20,
            child: _buildFloatingButton(),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawer(BuildContext context) {
    return Drawer(
      backgroundColor: const Color(0xFF020617), // Match the Dark Navy theme
      child: Column(
        children: [
          DrawerHeader(
            decoration: const BoxDecoration(
              border: Border(bottom: BorderSide(color: Colors.white10)),
            ),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.account_balance_wallet_rounded, color: Colors.orangeAccent, size: 40),
                  const SizedBox(height: 10),
                  Text(
                    'BUDGET buddy',
                    style: const TextStyle(color: Colors.orangeAccent, fontSize: 20),
                  ),
                ],
              ),
            ),
          ),
          _buildDrawerItem(
            icon: Icons.dashboard_rounded,
            title: 'Dashboard',
            onTap: () => Navigator.pop(context),
            isActive: true,
          ),
          _buildDrawerItem(
            icon: Icons.person_outline_rounded,
            title: 'Profile',
            onTap: () {
              Navigator.pop(context);

              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const IncomeTracker(),
                ),
              );
            },
          ),
          _buildDrawerItem(
            icon: Icons.track_changes_rounded,
            title: 'Expenses Tracker',
            onTap: () {
              Navigator.pop(context);
              // Navigation to Expenses Tracker placeholder
            },
          ),
          _buildDrawerItem(
            icon: Icons.settings_outlined,
            title: 'Setting',
            onTap: () {
              Navigator.pop(context);
              // Navigation to Setting page placeholder
            },
          ),
          const Spacer(),
          _buildDrawerItem(
            icon: Icons.logout_rounded,
            title: 'Logout',
            onTap: () {
              Navigator.of(context).popUntil((route) => route.isFirst);
            },
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    bool isActive = false,
  }) {
    return ListTile(
      leading: Icon(icon, color: isActive ? Colors.orangeAccent : Colors.white70),
      title: Text(
        title,
        style: TextStyle(
          color: isActive ? Colors.orangeAccent : Colors.white,
          fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
        ),
      ),
      onTap: onTap,
    );
  }

  Widget _buildTopBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Open Drawer Button (Menu)
          Builder(
            builder: (context) => GestureDetector(
              onTap: () => Scaffold.of(context).openDrawer(),
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 10),
                  ],
                ),
                child: const Icon(Icons.menu_rounded, color: Colors.black87, size: 22),
              ),
            ),
          ),
          Text(
            'BUDGET buddy',
            style: const TextStyle(
              color: Colors.orangeAccent,
              fontSize: 14,
              letterSpacing: 0.5,
            ),
          ),
          // Back Button
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 10),
                ],
              ),
              child: const Icon(Icons.arrow_back_ios_new, color: Colors.black87, size: 18),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTopSection() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Good Morning,',
              style: const TextStyle(
                color: Colors.black54,
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
            ),
            Text(
              'Ariff Siswa 👋',
              style: const TextStyle(
                color: Colors.black,
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              'Monday, 24 May 2024',
              style: const TextStyle(
                color: Colors.black38,
                fontSize: 11,
              ),
            ),
          ],
        ),
        Row(
          children: [
            _buildActionIcon(Icons.notifications_none_rounded),
            const SizedBox(width: 12),
            Container(
              padding: const EdgeInsets.all(2),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: Colors.purple.withValues(alpha: 0.2), width: 2),
              ),
              child: const CircleAvatar(
                radius: 20,
                backgroundImage: NetworkImage('https://i.pravatar.cc/150?u=ariff'),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildActionIcon(IconData icon) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 10),
        ],
      ),
      child: Icon(icon, color: Colors.black87, size: 22),
    );
  }

  Widget _buildBalanceCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF7C3AED), Color(0xFF4F46E5)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(32),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF7C3AED).withValues(alpha: 0.3),
            blurRadius: 20,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Available Balance',
                    style: const TextStyle(color: Colors.white70, fontSize: 13),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'RM 1,250.00',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      letterSpacing: -0.5,
                    ),
                  ),
                ],
              ),
              _build3DWallet(),
            ],
          ),
          const SizedBox(height: 24),
          Row(
            children: [
              _buildStatCard('Income', 'RM 2,500', Icons.arrow_downward, Colors.greenAccent),
              const SizedBox(width: 12),
              _buildStatCard('Expenses', 'RM 1,250', Icons.arrow_upward, Colors.orangeAccent),
            ],
          ),
        ],
      ),
    );
  }

  Widget _build3DWallet() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.15),
        shape: BoxShape.circle,
      ),
      child: const Icon(Icons.account_balance_wallet_rounded, color: Colors.white, size: 40),
    );
  }

  Widget _buildStatCard(String title, String amount, IconData icon, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(color: color.withValues(alpha: 0.2), shape: BoxShape.circle),
              child: Icon(icon, color: color, size: 14),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: Colors.white70, fontSize: 10)),
                Text(
                  amount,
                  style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProgressCards() {
    return Row(
      children: [
        _buildMiniProgress('Budget Progress', 0.65, '65%', Colors.purpleAccent),
        const SizedBox(width: 16),
        _buildMiniProgress('Saving Goals', 0.40, '40%', Colors.greenAccent),
      ],
    );
  }

  Widget _buildMiniProgress(String title, double value, String percent, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(color: Colors.black.withValues(alpha: 0.02), blurRadius: 10, offset: const Offset(0, 4)),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(color: Colors.black54, fontSize: 11, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: LinearProgressIndicator(
                value: value,
                backgroundColor: color.withValues(alpha: 0.1),
                valueColor: AlwaysStoppedAnimation<Color>(color),
                minHeight: 6,
              ),
            ),
            const SizedBox(height: 8),
            Text(percent, style: const TextStyle(color: Colors.black87, fontSize: 14, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  Widget _buildAnalyticsSection() {
    return Column(
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(32),
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 20)],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Expense Analytics', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildMockPieChart(),
                  _buildMockBarChart(),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildMockPieChart() {
    return Stack(
      alignment: Alignment.center,
      children: [
        SizedBox(
          width: 80,
          height: 80,
          child: CircularProgressIndicator(
            value: 0.75,
            strokeWidth: 12,
            backgroundColor: Colors.grey.shade100,
            valueColor: const AlwaysStoppedAnimation<Color>(Colors.purpleAccent),
          ),
        ),
        Text('75%', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
      ],
    );
  }

  Widget _buildMockBarChart() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        _bar(40, Colors.purple.shade200),
        _bar(60, Colors.purple.shade300),
        _bar(30, Colors.purple.shade400),
        _bar(80, Colors.purpleAccent),
        _bar(50, Colors.purple.shade600),
      ],
    );
  }

  Widget _bar(double height, Color color) {
    return Container(
      width: 8,
      height: height,
      margin: const EdgeInsets.only(left: 4),
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(4)),
    );
  }

  Widget _buildQuickActions() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        _actionItem('Pay', Icons.qr_code_scanner, Colors.red.shade100),
        _actionItem('Send', Icons.send_rounded, Colors.blue.shade100),
        _actionItem('Bill', Icons.receipt_rounded, Colors.green.shade100),
        _actionItem('Card', Icons.credit_card_rounded, Colors.orange.shade100),
      ],
    );
  }

  Widget _actionItem(String label, IconData icon, Color color) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(20)),
          child: Icon(icon, color: Colors.black87, size: 24),
        ),
        const SizedBox(height: 8),
        Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
      ],
    );
  }

  Widget _buildRecentTransactions() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(32),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Recent Transactions', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
              Text('See All', style: const TextStyle(color: Colors.blueAccent, fontSize: 11, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 20),
          _transactionRow('Food & Dining', 'May 24', '-RM 42.00', Icons.fastfood_rounded, Colors.orange.shade100),
          const SizedBox(height: 16),
          _transactionRow('Subscription', 'May 23', '-RM 55.00', Icons.movie_rounded, Colors.red.shade100),
        ],
      ),
    );
  }

  Widget _transactionRow(String title, String date, String amount, IconData icon, Color color) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(14)),
          child: Icon(icon, size: 18),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              Text(date, style: const TextStyle(color: Colors.black38, fontSize: 10)),
            ],
          ),
        ),
        Text(amount, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
      ],
    );
  }

  Widget _buildFloatingButton() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: const BoxDecoration(
        color: Color(0xFF7C3AED),
        shape: BoxShape.circle,
        boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 10, offset: Offset(0, 4))],
      ),
      child: const Icon(Icons.add, color: Colors.white, size: 28),
    );
  }
}